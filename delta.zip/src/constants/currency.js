const currency = '$'
export default currency