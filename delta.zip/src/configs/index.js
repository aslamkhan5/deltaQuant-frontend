export const config = {
  ApiBaseURL: process.env.REACT_APP_API_Base_Url,
  AppBaseURL: process.env.REACT_APP_BASE_URL,
  RECAPTCHA_API_KEY: process.env.REACT_APP_RECAPTCHA_API_KEY
};
